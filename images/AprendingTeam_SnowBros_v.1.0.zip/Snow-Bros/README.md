# Aprending Team
https://github.com/AMADE128/Snow-Bros
- Marc Pavon (Marckitus), Denis Deconinck (Denisdrk6), Himar Bravo (himar33), Pol Vazquez (AMADE128)
- This platform game consists on killing all the enemies to pass to the next level.
- The player has 3 lives, if he dies he'll respawn in the same level, but if you die 3 times, you'll be send to the menu. You can pass between the menu and the level by pressins "SPACE". The goal of the level is to turn all the enemies into snowballs, by shooting them several times. Once you turned all into snowballs, you'll win and be sent back to the menu.
# The controls in-game are the following:

-MOVE RIGHT: "D"
-MOVE LEFT: "A"
-JUMP: "W"
-SHOOT: "SPACE"
-ENABLE / DISABLE HITBOX: F1
-ENABLE / DISABLE GOD MODE: F2
-IN GOD MODE USE "WASD" TO FLY
-DIRECT WIN: F5
-DIRECT LOSE: F6
